to start project:
- please do npm install, to instal dependencies of the project
-npm start, to start the server 