var server = require('./server.js');
module.exports = {
    run: server.listen
}